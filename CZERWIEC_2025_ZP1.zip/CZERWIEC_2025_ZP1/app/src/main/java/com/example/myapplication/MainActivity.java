package com.example.myapplication; // zamień na swój pakiet

import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Widoki
    private View viewLargeColor;
    private SeekBar seekR, seekG, seekB;
    private TextView tvRValue, tvGValue, tvBValue;
    private Button btnPick;
    private TextView tvPickedColor;

    // Aktualne wartości suwaków (na żywo)
    private int currentR = 255;
    private int currentG = 255;
    private int currentB = 255;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Ustaw tytuł - tutaj wstaw swój numer zamiast 00000000000
        setTitle("Wzornik kolorów RGB. Wykonał 00000000000");

        bindViews();
        setupSeekBars();
        setupButton();

        // Inicjalne ustawienia (suwaki już ustawione w XML na 255, ale aktualizujemy UI)
        updateUiFromSeekbars();
        applyColorToLargeView();
    }

    private void bindViews() {
        viewLargeColor = findViewById(R.id.viewLargeColor);
        seekR = findViewById(R.id.seekR);
        seekG = findViewById(R.id.seekG);
        seekB = findViewById(R.id.seekB);
        tvRValue = findViewById(R.id.tvRValue);
        tvGValue = findViewById(R.id.tvGValue);
        tvBValue = findViewById(R.id.tvBValue);
        btnPick = findViewById(R.id.btnPick);
        tvPickedColor = findViewById(R.id.tvPickedColor);
    }

    private void setupSeekBars() {
        SeekBar.OnSeekBarChangeListener listener = new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // Aktualizuj aktualne wartości i UI
                currentR = seekR.getProgress();
                currentG = seekG.getProgress();
                currentB = seekB.getProgress();
                updateValueLabels();
                applyColorToLargeView();
            }

            @Override public void onStartTrackingTouch(SeekBar seekBar) { /* nie używane */ }

            @Override public void onStopTrackingTouch(SeekBar seekBar) { /* nie używane */ }
        };

        seekR.setOnSeekBarChangeListener(listener);
        seekG.setOnSeekBarChangeListener(listener);
        seekB.setOnSeekBarChangeListener(listener);
    }

    private void setupButton() {
        btnPick.setOnClickListener(v -> {
            // Po naciśnięciu przycisku ustaw kolor i tekst małego prostokąta
            int color = Color.rgb(currentR, currentG, currentB);
            tvPickedColor.setBackgroundColor(color);
            String rgbText = String.format("%d, %d, %d", currentR, currentG, currentB);
            tvPickedColor.setText(rgbText);

            // Jeśli tło tekstu jest ciemne, możesz ustawić kolor tekstu na biały dla czytelności:
            if (isColorDark(currentR, currentG, currentB)) {
                tvPickedColor.setTextColor(Color.WHITE);
            } else {
                tvPickedColor.setTextColor(Color.BLACK);
            }
        });
    }

    private void updateValueLabels() {
        tvRValue.setText(String.valueOf(currentR));
        tvGValue.setText(String.valueOf(currentG));
        tvBValue.setText(String.valueOf(currentB));
    }

    private void updateUiFromSeekbars() {
        currentR = seekR.getProgress();
        currentG = seekG.getProgress();
        currentB = seekB.getProgress();
        updateValueLabels();
    }

    private void applyColorToLargeView() {
        int color = Color.rgb(currentR, currentG, currentB);
        viewLargeColor.setBackgroundColor(color);
    }

    /**
     * Proste sprawdzenie czy kolor jest "ciemny" - użyte do ustawienia kontrastu tekstu.
     */
    private boolean isColorDark(int r, int g, int b) {
        // Luminancja prosta (percepcyjna wagi)
        double luminance = (0.299 * r + 0.587 * g + 0.114 * b);
        return luminance < 128;
    }
}
