package com.example.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.*;

public class MainActivity extends AppCompatActivity {

    private EditText editNumer, editImie, editNazwisko;
    private RadioGroup radioKolorOczu;
    private ImageView imageZdjecie, imageOdcisk;
    private Button buttonOK;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editNumer = findViewById(R.id.editNumer);
        editImie = findViewById(R.id.editImie);
        editNazwisko = findViewById(R.id.editNazwisko);
        radioKolorOczu = findViewById(R.id.radioKolorOczu);
        imageZdjecie = findViewById(R.id.imageZdjecie);
        imageOdcisk = findViewById(R.id.imageOdcisk);
        buttonOK = findViewById(R.id.buttonOK);

        // Po opuszczeniu pola numer
        editNumer.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean hasFocus) {
                if (!hasFocus) {
                    updateImages();
                }
            }
        });

        // Obsługa przycisku OK
        buttonOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                handleOkClick();
            }
        });
    }

    private void updateImages() {
        String numer = editNumer.getText().toString().trim();
        if (numer.isEmpty()) return;

        // Zastępujemy "-" na "_" bo w zasobach Androida nie można mieć myślników
        String zdjecieName = numer + "_zdjecie";
        String odciskName = numer + "_odcisk";

        int resZdjecie = getResources().getIdentifier(zdjecieName, "drawable", getPackageName());
        int resOdcisk = getResources().getIdentifier(odciskName, "drawable", getPackageName());

        if (resZdjecie != 0) {
            imageZdjecie.setImageResource(resZdjecie);
        } else {
            imageZdjecie.setImageDrawable(null);
        }

        if (resOdcisk != 0) {
            imageOdcisk.setImageResource(resOdcisk);
        } else {
            imageOdcisk.setImageDrawable(null);
        }
    }

    private void handleOkClick() {
        String imie = editImie.getText().toString().trim();
        String nazwisko = editNazwisko.getText().toString().trim();

        if (TextUtils.isEmpty(imie) || TextUtils.isEmpty(nazwisko)) {
            new AlertDialog.Builder(this)
                    .setMessage("Wprowadź dane")
                    .setPositiveButton("OK", null)
                    .show();
            return;
        }

        int selectedId = radioKolorOczu.getCheckedRadioButtonId();
        RadioButton selectedRadio = findViewById(selectedId);
        String kolor = selectedRadio.getText().toString();

        String message = imie + " " + nazwisko + " kolor oczu " + kolor;

        new AlertDialog.Builder(this)
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }
}
