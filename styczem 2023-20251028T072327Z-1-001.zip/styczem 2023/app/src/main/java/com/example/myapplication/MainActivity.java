package com.example.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

import com.example.myapplication.R;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    EditText editImie, editNazwisko, editIleZnakow;
    Spinner spinnerStanowisko;
    CheckBox checkMaleWielkie, checkCyfry, checkZnaki;
    Button btnGeneruj, btnZatwierdz;
    String wygenerowaneHaslo = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Dodaj pracownika - nr 12"); // numer zdającego
        setContentView(R.layout.activity_main);

        // Inicjalizacja kontrolek
        editImie = findViewById(R.id.editImie);
        editNazwisko = findViewById(R.id.editNazwisko);
        editIleZnakow = findViewById(R.id.editIleZnakow);
        spinnerStanowisko = findViewById(R.id.spinnerStanowisko);
        checkMaleWielkie = findViewById(R.id.checkMaleWielkie);
        checkCyfry = findViewById(R.id.checkCyfry);
        checkZnaki = findViewById(R.id.checkZnaki);
        btnGeneruj = findViewById(R.id.btnGeneruj);
        btnZatwierdz = findViewById(R.id.btnZatwierdz);

        // Ustawienie spinnera
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item,
                new String[]{"Kierownik", "Starszy programista", "Młodszy programista", "Tester"});
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerStanowisko.setAdapter(adapter);

        btnGeneruj.setOnClickListener(v -> generujHaslo());
        btnZatwierdz.setOnClickListener(v -> zatwierdzDane());
    }

    private void generujHaslo() {
        String maleLitery = "abcdefghijklmnopqrstuvwxyz";
        String wielkieLitery = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String cyfry = "0123456789";
        String znakiSpecjalne = "!@#$%^&*()_+-=";

        int ile;
        try {
            ile = Integer.parseInt(editIleZnakow.getText().toString());
        } catch (Exception e) {
            Toast.makeText(this, "Podaj liczbę znaków!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (ile <= 0) {
            Toast.makeText(this, "Liczba znaków musi być większa niż 0", Toast.LENGTH_SHORT).show();
            return;
        }

        StringBuilder haslo = new StringBuilder();
        Random rand = new Random();

        // początkowo wypełniamy małymi literami
        for (int i = 0; i < ile; i++) {
            haslo.append(maleLitery.charAt(rand.nextInt(maleLitery.length())));
        }

        // Zamiana wybranych pozycji zgodnie z wymaganiem (dla uproszczenia używamy stałych pozycji: 0,1,2)
        if (checkMaleWielkie.isChecked()) {
            haslo.setCharAt(0, wielkieLitery.charAt(rand.nextInt(wielkieLitery.length())));
        }
        if (checkCyfry.isChecked() && ile > 1) {
            haslo.setCharAt(1, cyfry.charAt(rand.nextInt(cyfry.length())));
        }
        if (checkZnaki.isChecked() && ile > 2) {
            haslo.setCharAt(2, znakiSpecjalne.charAt(rand.nextInt(znakiSpecjalne.length())));
        }

        wygenerowaneHaslo = haslo.toString();
        new AlertDialog.Builder(this)
                .setTitle("Wygenerowane hasło")
                .setMessage(wygenerowaneHaslo)
                .setPositiveButton("OK", null)
                .show();
    }

    private void zatwierdzDane() {
        String imie = editImie.getText().toString();
        String nazwisko = editNazwisko.getText().toString();
        String stanowisko = spinnerStanowisko.getSelectedItem().toString();

        if (imie.isEmpty() || nazwisko.isEmpty() || wygenerowaneHaslo.isEmpty()) {
            Toast.makeText(this, "Uzupełnij dane i wygeneruj hasło!", Toast.LENGTH_SHORT).show();
            return;
        }

        String komunikat = "Dane pracownika: " + imie + " " + nazwisko + " " + stanowisko + " Hasło: " + wygenerowaneHaslo;

        new AlertDialog.Builder(this)
                .setMessage(komunikat)
                .setPositiveButton("OK", null)
                .show();
    }
}
