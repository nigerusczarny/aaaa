package com.example.domekwgorach;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private int licznik = 0;
    private TextView tvLikes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnLike = findViewById(R.id.btnLike);
        Button btnDelete = findViewById(R.id.btnDelete);
        Button btnSave = findViewById(R.id.btnSave);
        tvLikes = findViewById(R.id.tvLikes);

        // Przycisk POLUB
        btnLike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                licznik++;
                updateLikes();
            }
        });

        // Przycisk USUŃ
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (licznik > 0) {
                    licznik--;
                }
                updateLikes();
            }
        });

        // Przycisk ZAPISZ (bez działania – można rozbudować)
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Tutaj można dodać logikę zapisu np. do pliku lub bazy danych
            }
        });
    }

    private void updateLikes() {
        tvLikes.setText(licznik + " polubień");
    }
}
