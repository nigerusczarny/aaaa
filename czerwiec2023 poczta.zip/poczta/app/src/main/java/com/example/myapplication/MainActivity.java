package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.*;

import com.example.myapplication.R;

public class MainActivity extends AppCompatActivity {

    RadioGroup rgType;
    RadioButton rbPocztowka, rbList, rbPaczka;
    ImageView imagePreview;
    TextView tvPriceLabel;
    EditText etPostalCode;
    Button btnCheckPrice, btnConfirm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle("Nadaj Przesyłkę – PESEL 00000000000");

        rgType = findViewById(R.id.rgType);
        rbPocztowka = findViewById(R.id.rbPocztowka);
        rbList = findViewById(R.id.rbList);
        rbPaczka = findViewById(R.id.rbPaczka);
        imagePreview = findViewById(R.id.imagePreview);
        tvPriceLabel = findViewById(R.id.tvPriceLabel);
        etPostalCode = findViewById(R.id.etPostalCode);
        btnCheckPrice = findViewById(R.id.btnCheckPrice);
        btnConfirm = findViewById(R.id.btnConfirm);

        rbPocztowka.setChecked(true);

        btnCheckPrice.setOnClickListener(v -> checkPrice());
        btnConfirm.setOnClickListener(v -> validatePostalCode());
    }

    private void checkPrice() {

        if (rbPocztowka.isChecked()) {
            imagePreview.setImageResource(R.drawable.pocztowka);
            tvPriceLabel.setText("Cena: 1 zł");

        } else if (rbList.isChecked()) {
            imagePreview.setImageResource(R.drawable.list);
            tvPriceLabel.setText("Cena: 1,5 zł");

        } else if (rbPaczka.isChecked()) {
            imagePreview.setImageResource(R.drawable.paczka);
            tvPriceLabel.setText("Cena: 10 zł");
        }
    }

    private void validatePostalCode() {

        String code = etPostalCode.getText().toString().trim();

        if (code.length() != 5) {
            Toast.makeText(this, "Nieprawidłowa liczba cyfr w kodzie pocztowym", Toast.LENGTH_LONG).show();
            return;
        }

        for (char c : code.toCharArray()) {
            if (!Character.isDigit(c)) {
                Toast.makeText(this, "Kod pocztowy powinien się składać z samych cyfr", Toast.LENGTH_LONG).show();
                return;
            }
        }

        Toast.makeText(this, "Dane przesyłki zostały wprowadzone", Toast.LENGTH_LONG).show();
    }
}
