package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Photo> photos = new ArrayList<>();
    private LinearLayout galleryContainer;
    private CheckBox checkFlowers, checkAnimals, checkCars;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        galleryContainer = findViewById(R.id.galleryContainer);
        checkFlowers = findViewById(R.id.checkFlowers);
        checkAnimals = findViewById(R.id.checkAnimals);
        checkCars = findViewById(R.id.checkCars);

        loadPhotosFromTxt();
        displayPhotos();

        CompoundButton.OnCheckedChangeListener listener = (buttonView, isChecked) -> displayPhotos();
        checkFlowers.setOnCheckedChangeListener(listener);
        checkAnimals.setOnCheckedChangeListener(listener);
        checkCars.setOnCheckedChangeListener(listener);

        try {
            InputStream is = getAssets().open("dane.txt");
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            String firstLine = reader.readLine();
            Toast.makeText(this, "Pierwsza linia: " + firstLine, Toast.LENGTH_LONG).show();
            reader.close();
            is.close();
        } catch (Exception e) {
            Toast.makeText(this, "❌ Nie znaleziono pliku dane.txt!", Toast.LENGTH_LONG).show();
        }

    }

    private void loadPhotosFromTxt() {
        try {
            InputStream is = getAssets().open("dane.txt");
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            StringBuilder builder = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                builder.append(line.trim());
            }
            reader.close();
            is.close();

            String text = builder.toString();
            Toast.makeText(this, "Plik dane.txt wczytany: " + text.length() + " znaków", Toast.LENGTH_SHORT).show();

            String[] objects = text.split("\\},\\s*\\{");

            for (String obj : objects) {
                obj = obj.replace("{", "").replace("}", "").trim();
                String[] fields = obj.split(",");

                int id = 0, category = 0, downloads = 0;
                String alt = "", filename = "";

                for (String field : fields) {
                    String[] parts = field.split(":", 2);
                    if (parts.length < 2) continue;
                    String key = parts[0].trim().replace("\"", "");
                    String value = parts[1].trim().replace("\"", "").replace("}", "").replace(",", "");

                    switch (key) {
                        case "id":
                            id = safeParseInt(value);
                            break;
                        case "alt":
                            alt = value;
                            break;
                        case "filename":
                            filename = value;
                            break;
                        case "category":
                            category = safeParseInt(value);
                            break;
                        case "downloads":
                            downloads = safeParseInt(value);
                            break;
                    }
                }

                photos.add(new Photo(id, alt, filename, category, downloads));
            }

            Toast.makeText(this, "Wczytano zdjęć: " + photos.size(), Toast.LENGTH_LONG).show();

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "❌ Błąd wczytania: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private int safeParseInt(String s) {
        try {
            s = s.replaceAll("[^0-9]", "");
            if (s.isEmpty()) return 0;
            return Integer.parseInt(s);
        } catch (Exception e) {
            return 0;
        }
    }




    private void displayPhotos() {
        galleryContainer.removeAllViews();

        for (Photo photo : photos) {
            if ((photo.category == 1 && checkFlowers.isChecked()) ||
                    (photo.category == 2 && checkAnimals.isChecked()) ||
                    (photo.category == 3 && checkCars.isChecked())) {

                LinearLayout block = new LinearLayout(this);
                block.setOrientation(LinearLayout.VERTICAL);
                block.setPadding(10, 10, 10, 10);

                ImageView img = new ImageView(this);
                try {
                    InputStream is = getAssets().open("zdjecia/" + photo.filename);
                    img.setImageBitmap(BitmapFactory.decodeStream(is));
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                    TextView error = new TextView(this);
                    error.setText("❌ Brak pliku: " + photo.filename);
                    error.setTextColor(0xFFFF0000);
                    block.addView(error);
                }

                img.setAdjustViewBounds(true);
                img.setLayoutParams(new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        400
                ));

                TextView downloadsText = new TextView(this);
                downloadsText.setText("Pobrań: " + photo.downloads);
                downloadsText.setTextColor(0xFFFFFFFF);
                downloadsText.setTextSize(16);

                Button btn = new Button(this);
                btn.setText("Pobierz");
                btn.setBackgroundColor(0xFFCC3366);
                btn.setTextColor(0xFFFFFFFF);
                btn.setOnClickListener(v -> {
                    photo.downloads++;
                    downloadsText.setText("Pobrań: " + photo.downloads);
                });

                block.addView(img);
                block.addView(downloadsText);
                block.addView(btn);
                galleryContainer.addView(block);
            }
        }
    }

    private static class Photo {
        int id, category, downloads;
        String alt, filename;
        Photo(int id, String alt, String filename, int category, int downloads) {
            this.id = id;
            this.alt = alt;
            this.filename = filename;
            this.category = category;
            this.downloads = downloads;
        }
    }
}
