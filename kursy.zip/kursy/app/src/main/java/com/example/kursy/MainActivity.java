package com.example.kursy;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {

    // Tablica kursów
    private String[] courses = {
            "Programowanie w C#",
            "Angular dla początkujących",
            "Kurs Django"
    };

    private TextView txtCourseCount;
    private TextInputEditText inputName, inputNumber;
    private Button btnSave;

    private LinearLayout courseContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtCourseCount = findViewById(R.id.txtCourseCount);
        inputName = findViewById(R.id.inputName);
        inputNumber = findViewById(R.id.inputNumber);
        btnSave = findViewById(R.id.btnSave);
        courseContainer = findViewById(R.id.courseContainer);

        // Wyświetlenie liczby kursów
        txtCourseCount.setText("Liczba kursów: " + courses.length);

        // Dynamiczne dodanie kursów do listy
        for (int i = 0; i < courses.length; i++) {
            TextView textView = new TextView(this);
            textView.setText((i + 1) + ". " + courses[i]);
            textView.setTextSize(18);
            textView.setPadding(0, 6, 0, 6);
            courseContainer.addView(textView);
        }

        // Obsługa przycisku
        btnSave.setOnClickListener(v -> {
            String name = inputName.getText().toString().trim();
            String numString = inputNumber.getText().toString().trim();

            Log.i("APP", "----- Zapis do kursu -----");
            Log.i("APP", name);

            if (numString.isEmpty()) {
                Log.i("APP", "Nieprawidłowy numer kursu");
                return;
            }

            try {
                int num = Integer.parseInt(numString) - 1;
                if (num >= 0 && num < courses.length) {
                    Log.i("APP", courses[num]);
                } else {
                    Log.i("APP", "Nieprawidłowy numer kursu");
                }
            } catch (NumberFormatException e) {
                Log.i("APP", "Nieprawidłowy numer kursu");
            }
        });
    }
}
