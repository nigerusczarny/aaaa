package com.example.kursy; // <- dopasuj do swojego package name

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "APP";

    // Tablica kursów (może się zmieniać)
    private String[] courses = {
            "Programowanie w C#",
            "Angular dla początkujących",
            "Kurs Django"
    };

    private TextView txtCourseCount;
    private EditText inputName, inputNumber;
    private Button btnSave;
    private LinearLayout courseContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // upewnij się, że layout ma taką nazwę

        // powiązanie widoków
        txtCourseCount = findViewById(R.id.txtCourseCount);
        inputName = findViewById(R.id.inputName);
        inputNumber = findViewById(R.id.inputNumber);
        btnSave = findViewById(R.id.btnSave);
        courseContainer = findViewById(R.id.courseContainer);

        // ustaw licznik kursów
        txtCourseCount.setText("Liczba kursów: " + courses.length);

        // dynamicznie dodaj numerowaną listę kursów
        courseContainer.removeAllViews();
        for (int i = 0; i < courses.length; i++) {
            TextView tv = new TextView(this);
            tv.setText((i + 1) + ". " + courses[i]);
            tv.setTextSize(18);
            tv.setPadding(0, 6, 0, 6);
            courseContainer.addView(tv);
        }

        // obsługa kliknięcia przycisku
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name = inputName.getText() != null ? inputName.getText().toString().trim() : "";
                String numString = inputNumber.getText() != null ? inputNumber.getText().toString().trim() : "";

                String message = name + "\n";

                if (numString.isEmpty()) {
                    message += "Nieprawidłowy numer kursu";
                } else {
                    try {
                        int idx = Integer.parseInt(numString) - 1;
                        if (idx >= 0 && idx < courses.length) {
                            message += courses[idx];
                        } else {
                            message += "Nieprawidłowy numer kursu";
                        }
                    } catch (NumberFormatException e) {
                        message += "Nieprawidłowy numer kursu";
                    }
                }

                Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
            }
        });

    }
}
