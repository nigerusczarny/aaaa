package com.example.styczen2024_zp2;

import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    // Widoki
    private EditText ownerNameEditText;
    private ListView speciesListView;
    private SeekBar ageSeekBar;
    private TextView ageValueTextView;
    private EditText purposeEditText;
    private TextView timeValueTextView;
    private Button okButton;
    private TextView resultTextView;

    // Dane
    private final String[] speciesItems = new String[]{"Pies", "Kot", "Świnka morska"};
    private int selectedSpeciesPosition = 0;
    private final int MAX_DOG = 18;
    private final int MAX_CAT = 20;
    private final int MAX_GUINEA = 9;


    private int selectedHour = 16;
    private int selectedMinute = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ownerNameEditText = findViewById(R.id.ownerNameEditText);
        speciesListView = findViewById(R.id.speciesListView);
        ageSeekBar = findViewById(R.id.ageSeekBar);
        ageValueTextView = findViewById(R.id.ageValueTextView);
        purposeEditText = findViewById(R.id.purposeEditText);
        timeValueTextView = findViewById(R.id.timeValueTextView);
        okButton = findViewById(R.id.okButton);
        resultTextView = findViewById(R.id.resultTextView);

        ArrayAdapter<String> speciesAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_list_item_single_choice, speciesItems);
        speciesListView.setAdapter(speciesAdapter);
        speciesListView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        speciesListView.setItemChecked(selectedSpeciesPosition, true); // wybierz pierwszy element

        setSeekBarMaxForSpecies(speciesItems[selectedSpeciesPosition]);

        speciesListView.setOnItemClickListener((AdapterView<?> parent, View view, int position, long id) -> {
            selectedSpeciesPosition = position;
            String species = speciesItems[position];
            setSeekBarMaxForSpecies(species);
        });

        ageSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                ageValueTextView.setText(String.valueOf(progress));
            }

            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        updateTimeTextView();

        timeValueTextView.setOnClickListener(v -> {
            TimePickerDialog timePicker = new TimePickerDialog(
                    MainActivity.this,
                    (view, hourOfDay, minute) -> {
                        selectedHour = hourOfDay;
                        selectedMinute = minute;
                        updateTimeTextView();
                    },
                    selectedHour, selectedMinute, false // false -> 12-godzinny (AM/PM)
            );
            timePicker.show();
        });

        okButton.setOnClickListener(v -> {
            String owner = ownerNameEditText.getText().toString().trim();
            String species = speciesItems[selectedSpeciesPosition];
            int age = ageSeekBar.getProgress();
            String purpose = purposeEditText.getText().toString().trim();
            String time = timeValueTextView.getText().toString();

            String message = owner + ", " + species + ", " + age + ", " + purpose + ", " + time;

            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Zapisana Wizyta")
                    .setMessage(message)
                    .setPositiveButton("OK", null)
                    .show();

            resultTextView.setText(message);
        });
    }

    /**
     * Ustawia maksymalną wartość suwaka w zależności od wybranego gatunku.
     * Jeżeli aktualna wartość suwaka przekracza nowy max -> ustawiamy ją na max.
     */
    private void setSeekBarMaxForSpecies(String species) {
        int newMax;
        switch (species) {
            case "Pies":
                newMax = MAX_DOG;
                break;
            case "Kot":
                newMax = MAX_CAT;
                break;
            case "Świnka morska":
                newMax = MAX_GUINEA;
                break;
            default:
                newMax = 20;
        }

        // SeekBar#setMax przyjmuje wartość maksymalną - progress będzie w zakresie 0..newMax
        ageSeekBar.setMax(newMax);

        // jeżeli aktualna wartość > newMax, zredukuj ją
        if (ageSeekBar.getProgress() > newMax) {
            ageSeekBar.setProgress(newMax);
            ageValueTextView.setText(String.valueOf(newMax));
        }
    }

    /**
     * Aktualizuje widoczny tekst czasu (np. "4:00 PM") używając lokalnego formatu czasu.
     */
    private void updateTimeTextView() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, selectedHour);
        cal.set(Calendar.MINUTE, selectedMinute);
        DateFormat timeFormatter = DateFormat.getTimeInstance(DateFormat.SHORT, Locale.getDefault());
        String formatted = timeFormatter.format(cal.getTime());
        // W niektórych lokalizacjach DateFormat.SHORT może zwrócić "16:00" - to jest OK.
        timeValueTextView.setText(formatted);
    }
}
