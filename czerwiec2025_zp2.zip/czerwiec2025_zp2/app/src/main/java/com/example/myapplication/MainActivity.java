package com.example.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;

public class MainActivity extends AppCompatActivity {

    private static final int CREATE_FILE_REQUEST = 1;

    private EditText editKey, editPlain;
    private TextView textEncrypted;
    private Button btnEncrypt, btnSave;

    private static final String STUDENT_NUMBER = "00000000000";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Szyfrowanie. Wykonane przez " + STUDENT_NUMBER);
        setContentView(R.layout.activity_main);

        editKey = findViewById(R.id.editKey);
        editPlain = findViewById(R.id.editPlain);
        textEncrypted = findViewById(R.id.textEncrypted);
        btnEncrypt = findViewById(R.id.btnEncrypt);
        btnSave = findViewById(R.id.btnSave);

        applyRoundedBorder(textEncrypted);

        btnEncrypt.setOnClickListener(v -> {
            String keyText = editKey.getText().toString().trim();
            int key;
            try {
                key = Integer.parseInt(keyText);
            } catch (Exception e) {
                key = 0;
            }

            String plain = editPlain.getText().toString();
            String cipher = caesar(plain, key);
            textEncrypted.setText(cipher);
        });

        btnSave.setOnClickListener(v -> {
            String text = textEncrypted.getText().toString();
            if (text.isEmpty()) {
                Toast.makeText(this, "Brak tekstu do zapisania", Toast.LENGTH_SHORT).show();
                return;
            }

            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_TITLE, "szyfr.txt");
            startActivityForResult(intent, CREATE_FILE_REQUEST);
        });
    }

    private void applyRoundedBorder(TextView view) {
        GradientDrawable border = new GradientDrawable();
        border.setShape(GradientDrawable.RECTANGLE);
        border.setStroke(4, 0xFFFAEBD7);
        border.setCornerRadius(20);
        border.setColor(0x00000000);
        view.setBackground(border);
    }

    /** Szyfr Cezara */
    private String caesar(String text, int key) {
        StringBuilder sb = new StringBuilder();
        int k = key % 26;

        for (char c : text.toCharArray()) {
            if (c >= 'a' && c <= 'z') {
                sb.append((char) ((c - 'a' + k + 26) % 26 + 'a'));
            } else if (c >= 'A' && c <= 'Z') {
                sb.append((char) ((c - 'A' + k + 26) % 26 + 'A'));
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CREATE_FILE_REQUEST && resultCode == Activity.RESULT_OK) {
            if (data != null && data.getData() != null) {
                saveToFile(data.getData(), textEncrypted.getText().toString());
            }
        }
    }

    private void saveToFile(Uri uri, String content) {
        try (OutputStream out = getContentResolver().openOutputStream(uri);
             Writer writer = new OutputStreamWriter(out, StandardCharsets.UTF_8)) {

            writer.write(content);
            writer.flush();

            Toast.makeText(this, "Zapisano plik", Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            Toast.makeText(this, "Błąd zapisu: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
