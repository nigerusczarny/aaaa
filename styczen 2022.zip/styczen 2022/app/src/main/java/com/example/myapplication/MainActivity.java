package com.example.myapplication;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText editTextEmail, editTextPassword, editTextRepeatPassword;
    TextView textViewMessage;
    Button buttonSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPassword = findViewById(R.id.editTextPassword);
        editTextRepeatPassword = findViewById(R.id.editTextRepeatPassword);
        textViewMessage = findViewById(R.id.textViewMessage);
        buttonSubmit = findViewById(R.id.buttonSubmit);

        buttonSubmit.setOnClickListener(v -> validateForm());
    }

    private void validateForm() {
        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString();
        String repeatPassword = editTextRepeatPassword.getText().toString();

        if (!email.contains("@")) {
            textViewMessage.setText("Nieprawidłowy adres e-mail");
        } else if (!password.equals(repeatPassword)) {
            textViewMessage.setText("Hasła się różnią");
        } else {
            textViewMessage.setText("Witaj " + email);
        }
    }
}
